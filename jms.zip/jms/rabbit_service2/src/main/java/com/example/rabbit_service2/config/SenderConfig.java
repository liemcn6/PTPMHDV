package com.example.rabbit_service2.config;


import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class SenderConfig {

    @Value("${app.rabbitMQ.queue_name}")
    private String message;

    @Bean
    public Queue queue() {
        return new Queue(message, true);
    }
}
