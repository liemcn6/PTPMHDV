package com.example.rabbit_service2.controller;


import com.example.rabbit_service2.config.QueueSender;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/jms")
public class TestController {

    @Autowired
    private QueueSender queueSender;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @GetMapping("/send")
    public String send(@RequestParam(name = "message") String message){
//        queueSender.send(message);
        rabbitTemplate.convertAndSend("test_topic", "routing_key_test", message);
//        return "ok. done";
        return "ok. done";
    }
}
