package com.example.rabbit_service2;

import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableRabbit
public class RabbitService2Application {

    public static void main(String[] args) {
        SpringApplication.run(RabbitService2Application.class, args);
    }

}
